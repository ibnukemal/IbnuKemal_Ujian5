package com.sqa.ibnukemalujian5.driver;

import org.openqa.selenium.WebDriver;

public interface DriverStrategy {

	public WebDriver setStrategy();
}
